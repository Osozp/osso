<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex justify-end mb-4">
         <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <a href="<?php echo e(route('admin.products.create')); ?>">Nuevo Producto</a>
          <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    
     <div class="relative overflow-x-auto mb-4 ">
         <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
             <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                 <tr>
                    <th scope="col" class="px-6 py-3">
                        marca
                    </th>
                    <th scope="col" class="px-6 py-3">
                        sku
                    </th>
                    <th scope="col" class="px-6 py-3">
                        titulo
                    </th>
                    <th scope="col" class="px-6 py-3">
                        cantidad
                    </th>
                    <th scope="col" class="px-6 py-3">
                        tallas
                    </th>
                    <th scope="col" class="px-6 py-3">
                        precio
                    </th>
                    <th scope="col" class="px-6 py-3">
                        descripcion
                    </th>
                    <th scope="col" class="px-6 py-3">
                        publicado
                    </th>
                    <th scope="col" class="px-6 py-3">
                        acciones
                    </th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                     
                     <td class="px-6 py-4">
                         <?php echo e($product->category->name); ?>

                     </td>
                     <td class="px-6 py-4">
                        <?php echo e($product->sku); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($product->title); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($product->stock); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php $__currentLoopData = $product->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($tag->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($product->price); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($product->description); ?>

                    </td>
                    <td class="px-6 py-4">
                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300' => $product->published,
                            'bg-red-100 text-red-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-red-900 dark:text-red-300' => ! $product->published]); ?>">
                            <?php echo e($product->published ? 'Habilitado' : 'Desabilitado'); ?>

                        </span>
                    </td>
                     <td class="px-6 py-4">
                         <a href="<?php echo e(route('admin.products.edit',$product)); ?>">Editar</a>
                     </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
             </tbody>
         </table>
     </div>
     <div class="mt-4">
         <?php echo e($products->links()); ?>

     </div>
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\osso\resources\views/admin/products/index.blade.php ENDPATH**/ ?>