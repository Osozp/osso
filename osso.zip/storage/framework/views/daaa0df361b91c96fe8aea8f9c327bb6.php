<div>
    <!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div><?php /**PATH C:\xampp\htdocs\laravel\osso\resources\views/components/master-layout.blade.php ENDPATH**/ ?>