<?php if (isset($component)) { $__componentOriginal09258b082cb7feea5c3a304d0211a36c = $component; } ?>
<?php $component = App\View\Components\MasterLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MasterLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	<main class="bg_gray">
	    <div class="container margin_30">
	        <div class="page_header">
	            <div class="breadcrumbs">
	                <ul>
	                    <li><a href="#">Inicio</a></li>
	                    <li><a href="#"><?php echo e($product->category->name); ?></a></li>
	                    <li><?php echo e($product->sku); ?></li>
	                </ul>
	            </div>
	            <h1><?php echo e($product->title); ?></h1>
	        </div>
			<div class="row justify-content-center">
	            <div class="col-lg-8">
	                <div class="owl-carousel owl-theme prod_pics magnific-gallery">
						<?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<img src="<?php echo e(Storage::url($image->url)); ?>" alt="">
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                </div>
	            </div>
	        </div>
	    </div>
	    
	    <div class="bg_white">
	        <div class="container margin_60_35">
	            <div class="row justify-content-between">
	                <div class="col-lg-6">
	                    <div class="prod_info version_2">
	                        <span class="rating"><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star voted"></i><i class="icon-star"></i><em>4 reviews</em></span>
	                        <p><small>SKU: <?php echo e($product->sku); ?></small><br><?php echo e($product->description); ?></p>
	                        
	                    </div>
	                </div>
	                <div class="col-lg-5">
	                    <div class="prod_options version_2">
	                        <div class="row">
	                            <label class="col-xl-7 col-lg-5 col-md-6 col-6"><strong>Tallas</strong></label>
	                            <div class="col-xl-5 col-lg-5 col-md-6 col-6">
	                                <div class="custom-select-form">
	                                    <select class="wide">
											<?php $__currentLoopData = $product->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value=""><?php echo e($item->name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    </select>
	                                </div>
	                            </div>
	                        </div>
	                        <div class="row mt-3">
	                            <div class="col-lg-7 col-md-6 mb-3">
	                                <div class="price_main">
										<span class="new_price">
											Bs. <?php echo e($product->price); ?>

										</span>
										
									</div>
	                            </div>
	                            <div class="col-lg-5 col-md-6 mb-3">
									
	                                <div class="btn_add_to_cart"><a href="https://api.whatsapp.com/send?phone=59169955232&text=Quiero%20comprar%20este%20producto%20<?php echo e($path); ?>" class="btn_1">Quiero Comprarlo</a></div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <!-- /row -->
	        </div>
	    </div>
	    <!-- /bg_white -->

	    

	    <!-- /tabs_product -->

	    
	    <!-- /tab_content_wrapper -->

	    


	    <!-- /bg_white -->

	</main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $component = $__componentOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__componentOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\osso\resources\views/frontend/product/show.blade.php ENDPATH**/ ?>