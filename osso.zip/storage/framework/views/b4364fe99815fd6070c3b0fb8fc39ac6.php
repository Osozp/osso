<?php
    $links =[
        [
            'name' => 'Dashboard',
            'url' => route('admin.dashboard'),
            'active' => request()->routeIs('admin.dashboard'),
            'icon' => 'fa-solid fa-gauge',
        ],
        [
            'name' => 'Categorias',
            'url' => route('admin.categories.index'),
            'active' => request()->routeIs('admin.categories.*'),
            'icon' => 'fa-solid fa-folder-open',
        ],
        [
            'name' => 'Productos',
            'url' => route('admin.products.index'),
            'active' => request()->routeIs('admin.products.*'),
            'icon' => 'fa-solid fa-box',
        ],

    ];
?>
<aside id="logo-sidebar" 
    class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-white border-r border-gray-200 sm:translate-x-0 dark:bg-gray-800 dark:border-gray-700" 
    :class="{
        '-translate-x-full': !open,
        'transform-none': open,
    }"
    aria-label="Sidebar">
    <div class="h-full px-3 pb-4 overflow-y-auto bg-white dark:bg-gray-800">
        <ul class="space-y-2 font-medium">
            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e($link['url']); ?>" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
                        <i class="<?php echo e($link['icon']); ?> text-gray-500"></i>
                        <span class="ms-3"><?php echo e($link['name']); ?></span>
                    </a>
                </li> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
        </ul>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\laravel\osso\resources\views/layouts/includes/admin/aside.blade.php ENDPATH**/ ?>