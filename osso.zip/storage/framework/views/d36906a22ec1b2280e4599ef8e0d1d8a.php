<?php if (isset($component)) { $__componentOriginal09258b082cb7feea5c3a304d0211a36c = $component; } ?>
<?php $component = App\View\Components\MasterLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MasterLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <main>
		<div class="top_banner">
			<div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.3)">
				<div class="container">
					<div class="breadcrumbs">
						<ul>
							<li><a href="#">Inicio</a></li>
							<li><a href="#">Categoria</a></li>
							<li><?php echo e($category->name); ?></li>
						</ul>
					</div>
					<h1>Productos - <?php echo e($category->name); ?></h1>
				</div>
			</div>
			<img src="img/bg_cat_shoes.jpg" class="img-fluid" alt="">
		</div>
		<!-- /top_banner -->
			<div class="container margin_30">
			<div class="row small-gutters">		
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-6 col-md-4 col-xl-3">				
                        <a href="<?php echo e(route('producto.show',$product)); ?>">
							
								<div class="grid_item">
									<figure>
											<?php
												$int = 0;
											?>
											<?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($int <= 1): ?>
														<img class="img-fluid lazy" src="<?php echo e(Storage::url($image->url)); ?>">
													<?php
														$int = $int+1;
													?>
												<?php endif; ?>  
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</figure>
									<a href="<?php echo e(route('producto.show',$product)); ?>">
										<h3><?php echo e($product->title); ?></h3>
									</a>
									<div class="price_box">
										<span class="new_price">Bs. <?php echo e($product->price); ?></span>
									
									</div>
								</div>
							
						</a>
					</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- /grid_item -->
				
				<!-- /col -->		
			</div>
			<!-- /row -->

			<div class="mt-4">
				<?php echo e($products->links('partials.paginate')); ?>

			</div>
		</div>
		<!-- /container -->
	</main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $component = $__componentOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__componentOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\osso\resources\views/frontend/product/index.blade.php ENDPATH**/ ?>