<x-admin-layout>
    mostara categoria
</x-admin-layout>